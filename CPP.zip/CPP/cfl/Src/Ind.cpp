#include "cfl/Ind.hpp"

cfl::Ind::Ind(IInd *pNewInd)
    : m_pInd(pNewInd) {}