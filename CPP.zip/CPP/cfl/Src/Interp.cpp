#include "cfl/Interp.hpp"

using namespace cfl;

cfl::Interp::Interp(IInterp * pNewP)
  :m_uP(pNewP){}

