#include "cfl/Approx.hpp"
// CLASS Approx

cfl::Approx::Approx(IApprox *pNewP)
  : m_uP(pNewP) {}
