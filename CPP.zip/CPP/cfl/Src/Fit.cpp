#include "cfl/Fit.hpp"

using namespace cfl;

//class Fit

cfl::Fit::Fit(IFit *pNewP) : m_uP(pNewP) {}