#ifndef __test_Interp_hpp__
#define __test_Interp_hpp__

#include "cfl/Interp.hpp"

namespace test
{
void testInterp(const cfl::Interp &rInterp, const std::string &sInterp);
} // namespace test

#endif // of __test_Interp_hpp__
