#ifndef __test_cflMain_hpp__
#define __test_cflMain_hpp__

#include <functional>

namespace test
{
  std::function<void()> test_function();
}

#endif // of __test_cflMain_hpp__
